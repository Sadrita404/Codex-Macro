import board
import time
import digitalio
import keypad
import rotaryio
import usb_hid
from adafruit_hid.keyboard import Keyboard
from adafruit_hid.keycode import Keycode
from adafruit_hid.consumer_control import ConsumerControl
from adafruit_hid.consumer_control_code import ConsumerControlCode

class LEDManager:
    def __init__(self, power_pin, activity_pin):
        self.power_led = digitalio.DigitalInOut(power_pin)
        self.power_led.direction = digitalio.Direction.OUTPUT
        self.power_led.value = True
        
        self.activity_led = digitalio.DigitalInOut(activity_pin)
        self.activity_led.direction = digitalio.Direction.OUTPUT
        self.activity_led.value = False
        self.is_active = False

    def enable(self):
        self.is_active = True
        self.activity_led.value = self.is_active

    def disable(self):
        self.is_active = False
        self.activity_led.value = self.is_active


class HIDProcessor:
    def __init__(self):
        self.keyboard = Keyboard(usb_hid.devices)
        self.consumer_control = ConsumerControl(usb_hid.devices)

    def execute_press(self, action):
        if isinstance(action, tuple):
            self.keyboard.press(*action)
        elif isinstance(action, int):
            self.consumer_control.send(action)
        else:
            self.keyboard.press(action)

    def execute_release(self, action):
        if isinstance(action, tuple):
            self.keyboard.release(*action)
        elif not isinstance(action, int):
            self.keyboard.release(action)

    def execute_consumer(self, action):
        self.consumer_control.send(action)


class MacropadController:
    def __init__(self):
        self.leds = LEDManager(board.GP7, board.GP29)
        self.hid = HIDProcessor()
        
        self.matrix = keypad.KeyMatrix(
            row_pins=(board.GP0, board.GP1, board.GP2),
            column_pins=(board.GP3, board.GP4, board.GP5, board.GP6),
            columns_to_anodes=False,
        )
        
        self.matrix_keymap = [
            Keycode.A, Keycode.B, Keycode.C, Keycode.D,
            Keycode.E, Keycode.F, Keycode.G, Keycode.H,
            Keycode.I, Keycode.J, Keycode.K, Keycode.L,
        ]
        
        self.encoder = rotaryio.IncrementalEncoder(board.GP8, board.GP9)
        self.last_encoder_position = self.encoder.position
        
        self.direct_keys = keypad.Keys(
            pins=(board.GP10, board.GP11, board.GP12, board.GP13, board.GP14, board.GP15),
            value_when_pressed=False,
            pull=True
        )
        
        self.direct_keymap = [
            ConsumerControlCode.MUTE,
            (Keycode.PAGE_UP,),               
            (Keycode.PAGE_DOWN,),             
            (Keycode.ALT, Keycode.LEFT_ARROW),
            (Keycode.ALT, Keycode.RIGHT_ARROW),
            (Keycode.ENTER,)                  
        ]

    def poll_matrix(self):
        event = self.matrix.events.get()
        if event:
            index = event.key_number
            target_key = self.matrix_keymap[index]
            
            if event.pressed:
                self.leds.enable()
                self.hid.execute_press(target_key)
            else:
                self.hid.execute_release(target_key)
                self.leds.disable()

    def poll_encoder(self):
        current_position = self.encoder.position
        if current_position != self.last_encoder_position:
            self.leds.enable()
            position_difference = current_position - self.last_encoder_position
            
            if position_difference > 0:
                self.hid.execute_consumer(ConsumerControlCode.VOLUME_INCREMENT)
            else:
                self.hid.execute_consumer(ConsumerControlCode.VOLUME_DECREMENT)
                
            self.last_encoder_position = current_position
            self.leds.disable()

    def poll_direct_keys(self):
        event = self.direct_keys.events.get()
        if event:
            index = event.key_number
            target_action = self.direct_keymap[index]
            
            if event.pressed:
                self.leds.enable()
                self.hid.execute_press(target_action)
            else:
                self.hid.execute_release(target_action)
                self.leds.disable()

    def start_loop(self):
        while True:
            self.poll_matrix()
            self.poll_encoder()
            self.poll_direct_keys()
            time.sleep(0.001)

if __name__ == "__main__":
    macropad = MacropadController()
    macropad.start_loop()